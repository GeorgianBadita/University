Pentru a folosi multi_module_batch, tot ce trebuie facut este sa va asigurati ca modulul principal apare inaintea celorlalte module create,
modulele nu trebuie sa fie neaparat unul dupa altul.
Pentru a ne asigura de acest fapt, ar fi indicat sa executati urmatoarele operatiuni: click dreapta in folderul proiectului
selectati sort by, si selectati date modify, iar mai jos ascending, asa ne asiguram ca primul modul creat apare si primul
in lista de fisiere ale proiectului.

Dupa aceasta setare, doar copiati multi_module_batch in directorul proiectului, double-click pe el, dupa care doar scrieti
nume_modul_principal.exe (asta in cazul in care nu va este afisata nicio eroare de assamblare/linkeditare)

O zi buna [B]!
#!/bin/bash

touch itself1.sh
cat "itself.sh" > itself1.sh

#!/bin/bash

for p in $*; do
	len=${#p}
	echo $len
done

#!/bin/bash

read NAME

echo 'Welcome '$NAME

#include <stdio.h>
#include <math.h>

int main(){
	double x = 5;
	return 0;
}

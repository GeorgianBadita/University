function rez = lorentzTaylorDeg2(x)
  rez = 1 + x^2/2;
end
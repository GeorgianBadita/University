function x = Higham(x)
  x = h_rt(x);
  x = h_sq(x);
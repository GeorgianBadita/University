function x = h_rt(x)
  for i = 1:52
    x = sqrt(x);
  end
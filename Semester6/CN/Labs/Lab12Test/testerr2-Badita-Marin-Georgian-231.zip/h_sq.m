function x = h_sq(x)
  for i = 1:52
    x = x.^2;
  end
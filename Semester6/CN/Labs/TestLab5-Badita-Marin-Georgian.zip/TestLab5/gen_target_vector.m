function x = gen_target_vector(n)
  x = [3, 2, 2, ones(1, n-6), 2,2,3]';
end